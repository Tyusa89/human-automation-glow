-- Customer Support schema (minimal MVP)
create table if not exists public.support_customers (
  id uuid primary key default gen_random_uuid(),
  email text,
  name text,
  created_at timestamptz not null default now()
);

create table if not exists public.support_threads (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.support_customers(id) on delete cascade,
  status text not null default 'open' check (status in ('open','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.support_threads(id) on delete cascade,
  sender text not null check (sender in ('customer','agent')),
  body text not null,
  created_at timestamptz not null default now()
);

-- RLS: keep enabled for safety; server uses service role to bypass
alter table public.support_customers enable row level security;
alter table public.support_threads enable row level security;
alter table public.support_messages enable row level security;

-- For now, no public policies; access via server with service role only.
