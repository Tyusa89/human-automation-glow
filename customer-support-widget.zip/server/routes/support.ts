import express from "express";
import { createClient } from "@supabase/supabase-js";

const router = express.Router();

// Ensure these are set securely in your server env (NOT exposed to the browser)
const { SUPABASE_URL, SUPABASE_SERVICE_ROLE, SUPPORT_ADMIN_SECRET } = process.env as Record<string, string>;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE) {
  console.warn("[support] Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE. Routes will not work until set.");
}

const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE!, {
  auth: { persistSession: false },
});

// Helper: ensure customer + open thread
async function ensureOpenThread(customerId: string) {
  // Ensure customer exists
  let { data: customer, error: cErr } = await supabase
    .from("support_customers")
    .select("*")
    .eq("id", customerId)
    .single();
  if (cErr || !customer) {
    // create minimal customer
    const { data: cIns, error: cInsErr } = await supabase
      .from("support_customers")
      .insert({ id: customerId })
      .select()
      .single();
    if (cInsErr) throw cInsErr;
    customer = cIns;
  }

  // Find open thread or create
  let { data: thread, error: tErr } = await supabase
    .from("support_threads")
    .select("*")
    .eq("customer_id", customerId)
    .eq("status", "open")
    .maybeSingle();

  if (tErr) throw tErr;
  if (!thread) {
    const { data: tIns, error: tInsErr } = await supabase
      .from("support_threads")
      .insert({ customer_id: customerId, status: "open" })
      .select()
      .single();
    if (tInsErr) throw tInsErr;
    thread = tIns;
  }
  return thread;
}

// Customer posts a message (creates thread if missing)
router.post("/support/messages", async (req, res) => {
  try {
    const { customerId, text } = req.body as { customerId?: string; text?: string };
    if (!customerId || !text) return res.status(400).json({ ok: false, error: "customerId and text required" });

    const thread = await ensureOpenThread(customerId);
    const { data: msg, error: mErr } = await supabase
      .from("support_messages")
      .insert({ thread_id: thread.id, sender: "customer", body: text })
      .select()
      .single();
    if (mErr) throw mErr;

    return res.json({ ok: true, message: msg, threadId: thread.id });
  } catch (e: any) {
    console.error("[support] POST /support/messages", e);
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// Get messages for this customer's thread
router.get("/support/threads/:customerId/messages", async (req, res) => {
  try {
    const { customerId } = req.params;
    const { data: thread, error: tErr } = await supabase
      .from("support_threads")
      .select("id")
      .eq("customer_id", customerId)
      .eq("status", "open")
      .maybeSingle();
    if (tErr) throw tErr;

    if (!thread) return res.json({ ok: true, messages: [] });

    const { data: msgs, error: mErr } = await supabase
      .from("support_messages")
      .select("*")
      .eq("thread_id", thread.id)
      .order("created_at", { ascending: true });
    if (mErr) throw mErr;

    return res.json({ ok: true, messages: msgs || [], threadId: thread.id });
  } catch (e: any) {
    console.error("[support] GET /support/threads/:customerId/messages", e);
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// Agent reply (simple admin secret check for MVP)
router.post("/support/agents/reply", async (req, res) => {
  try {
    if (!SUPPORT_ADMIN_SECRET || req.headers["x-admin-secret"] !== SUPPORT_ADMIN_SECRET) {
      return res.status(401).json({ ok: false, error: "unauthorized" });
    }
    const { threadId, text } = req.body as { threadId?: string; text?: string };
    if (!threadId || !text) return res.status(400).json({ ok: false, error: "threadId and text required" });

    const { data: msg, error: mErr } = await supabase
      .from("support_messages")
      .insert({ thread_id: threadId, sender: "agent", body: text })
      .select()
      .single();
    if (mErr) throw mErr;

    return res.json({ ok: true, message: msg });
  } catch (e: any) {
    console.error("[support] POST /support/agents/reply", e);
    return res.status(500).json({ ok: false, error: e.message });
  }
});

export default router;
