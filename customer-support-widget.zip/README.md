# Customer Support Widget (Beta)

This package scaffolds a minimal, production-friendly **Customer Support Widget** for your EcoNest/Lovable app.

## What you get

- `src/components/support/SupportWidget.tsx` — in-app chat launcher + panel (Tailwind)
- `src/pages/admin/support/SupportSettings.tsx` — preview/settings stub
- `src/config/features.ts` — feature flag + defaults
- `server/routes/support.ts` — Express router with 3 endpoints
- `supabase/migrations/*_support.sql` — tables for customers, threads, messages
- `templates/app-features/customer-support-widget.json` — gallery metadata (optional)

## Prereqs

- React + Vite + Tailwind
- Express server at `server/index.js` (or similar)
- Supabase project
- `npm i @supabase/supabase-js` (server dependency)

## Install

1. **Copy files** into your repo preserving paths.
2. **Wire routes** in your Express server:
   ```ts
   // server/index.js or server/index.ts (ESM)
   import express from "express";
   import supportRoutes from "./routes/support.ts"; // path may vary
   const app = express();
   app.use(express.json());
   app.use("/api", supportRoutes);
   ```
3. **Run SQL migration** in Supabase SQL editor or CLI (see `supabase/migrations/*_support.sql`).

4. **Set environment variables (server)**:
   - `SUPABASE_URL` — your project URL
   - `SUPABASE_SERVICE_ROLE` — service role key (**server only**)
   - `SUPPORT_ADMIN_SECRET` — random string to authorize agent replies

5. **Feature flag** — render the widget globally:
   ```tsx
   // src/App.tsx (or root layout)
   import { features } from "./config/features";
   import SupportWidget from "./components/support/SupportWidget";
   export default function App() {
     return (
       <>
         {/* ... your app */}
         {features.supportWidget.enabled && (
           <SupportWidget
             color={features.supportWidget.color}
             position={features.supportWidget.position}
             greeting={features.supportWidget.greeting}
           />
         )}
       </>
     );
   }
   ```

6. **(Optional) Admin settings page**
   Add a route to `/admin/support` pointing to `SupportSettings.tsx`.

## API

- `POST /api/support/messages` — `{ customerId, text }` → creates thread if needed, inserts message as "customer".
- `GET /api/support/threads/:customerId/messages` — returns `{ messages, threadId }` for open thread.
- `POST /api/support/agents/reply` — header `x-admin-secret: SUPPORT_ADMIN_SECRET`, body `{ threadId, text }` inserts "agent" reply.

> MVP uses a simple admin secret. For production, gate agent endpoints behind your auth (JWT) and restrict by role.

## Notes

- The widget stores a random `customerId` in `localStorage` to persist the conversation anonymously.
- All DB writes/reads flow through the server using the **service role** (so you don't need client-side RLS policies yet).
- You can extend to email/SMS notifications later.

## Uninstall

- Remove the `<SupportWidget />` import/render.
- Remove `/api` support routes.
- Optionally drop tables: `support_messages`, `support_threads`, `support_customers`.
