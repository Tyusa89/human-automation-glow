export const features = {
  supportWidget: {
    enabled: true,
    color: "#0ea5e9",
    position: "right" as "left" | "right",
    greeting: "How can we help?",
  },
};
