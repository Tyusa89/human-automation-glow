import { useState } from "react";
import SupportWidget from "../../components/support/SupportWidget";

export default function SupportSettings() {
  const [color, setColor] = useState("#0ea5e9");
  const [pos, setPos] = useState<"left"|"right">("right");
  const [greeting, setGreeting] = useState("How can we help?");

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <h1 className="text-2xl font-bold">Support Widget Settings</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <label className="space-y-1">
          <div className="text-sm font-medium">Brand Color</div>
          <input value={color} onChange={e => setColor(e.target.value)} className="border rounded px-3 py-2 w-full" />
        </label>
        <label className="space-y-1">
          <div className="text-sm font-medium">Position</div>
          <select value={pos} onChange={e => setPos(e.target.value as "left"|"right")} className="border rounded px-3 py-2 w-full">
            <option value="right">Right</option>
            <option value="left">Left</option>
          </select>
        </label>
        <label className="space-y-1 md:col-span-1 col-span-1">
          <div className="text-sm font-medium">Greeting</div>
          <input value={greeting} onChange={e => setGreeting(e.target.value)} className="border rounded px-3 py-2 w-full" />
        </label>
      </div>

      <div>
        <div className="text-sm font-medium mb-2">Preview</div>
        <div className="relative h-[480px] border rounded-lg flex items-end justify-end p-8">
          <SupportWidget color={color} position={pos} greeting={greeting} />
        </div>
      </div>

      <p className="text-sm text-gray-600">
        Saving: wire these fields to your config store or backend. For MVP, you can export a static config in <code>src/config/features.ts</code>.
      </p>
    </div>
  );
}
