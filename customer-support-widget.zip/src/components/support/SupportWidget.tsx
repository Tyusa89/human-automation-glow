import { useEffect, useMemo, useRef, useState } from "react";

/**
 * Lightweight in-app support chat widget.
 * - Stores a customerId in localStorage (anonymous by default).
 * - Creates an "open" thread on first message.
 * - Polls for new messages every few seconds.
 *
 * Wire your API at /api/support/messages and /api/support/threads/:customerId/messages.
 * TailwindCSS is assumed in your project.
 */
export default function SupportWidget({
  color = "#0ea5e9",
  position = "right",
  greeting = "How can we help?",
  pollMs = 5000,
}: {
  color?: string;
  position?: "left" | "right";
  greeting?: string;
  pollMs?: number;
}) {
  const [open, setOpen] = useState(false);
  const [customerId, setCustomerId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Array<{ id: string; sender: "customer" | "agent"; body: string; created_at: string }>>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const pollRef = useRef<number | null>(null);

  useEffect(() => {
    // Seed customerId if missing
    let id = localStorage.getItem("support_customer_id");
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem("support_customer_id", id);
    }
    setCustomerId(id);
  }, []);

  // Fetch messages for this customer's thread
  const fetchMessages = async () => {
    if (!customerId) return;
    try {
      const res = await fetch(`/api/support/threads/${customerId}/messages`);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.messages || []);
    } catch (e) {
      // swallow for MVP
      console.error(e);
    }
  };

  useEffect(() => {
    if (!customerId) return;
    fetchMessages();
    if (pollRef.current) window.clearInterval(pollRef.current);
    pollRef.current = window.setInterval(fetchMessages, pollMs);
    return () => {
      if (pollRef.current) window.clearInterval(pollRef.current);
    };
  }, [customerId, pollMs]);

  const sendMessage = async () => {
    if (!input.trim() || !customerId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/support/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customerId, text: input.trim() }),
      });
      if (res.ok) {
        setInput("");
        fetchMessages();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const containerClass = useMemo(
    () => `fixed bottom-6 ${position === "left" ? "left-6" : "right-6"} z-50`,
    [position]
  );

  return (
    <div className={containerClass}>
      {open && (
        <div className="w-80 h-96 rounded-2xl shadow-xl bg-white overflow-hidden border border-gray-200">
          <div
            className="p-3 font-semibold flex items-center justify-between"
            style={{ background: color, color: "#fff" }}
          >
            <span>Support</span>
            <button
              className="text-xs underline"
              onClick={() => setOpen(false)}
              aria-label="Close support chat"
            >
              Close
            </button>
          </div>
          <div className="p-3 text-sm text-gray-700 border-b">{greeting}</div>

          <div className="p-3 space-y-2 overflow-y-auto h-56">
            {messages.length === 0 && (
              <div className="text-xs text-gray-500">No messages yet—start the conversation below.</div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.sender === "customer" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`px-3 py-2 rounded-2xl text-sm max-w-[70%] ${m.sender === "customer" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-800"}`}
                >
                  {m.body}
                  <div className="text-[10px] opacity-60 mt-1">{new Date(m.created_at).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 border-t flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 text-sm border rounded-xl px-3 py-2 outline-none focus:ring"
            />
            <button
              disabled={loading || !input.trim()}
              onClick={sendMessage}
              className="text-white rounded-xl px-3 py-2 disabled:opacity-50"
              style={{ background: color }}
            >
              Send
            </button>
          </div>
        </div>
      )}

      <button
        className="rounded-full shadow-lg px-4 py-3 text-white"
        style={{ background: color }}
        onClick={() => setOpen(!open)}
        aria-label="Open support chat"
      >
        {open ? "Close" : "Chat"}
      </button>
    </div>
  );
}
